require('chromedriver');
const {Builder, By, until} = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const assert = require('assert');
require('dotenv').config();

(async function openChromeTest() {
  let driver = null;
  let configs = {
    shopUrls: {
      base: process.env.SHOP_BASE_URL,
      login: process.env.SHOP_LOGIN_URL,
      product: process.env.SHOP_PRODUCT_URL,
      order: process.env.SHOP_ORDER_URL
    },
    user: {
      email: process.env.USER_EMAIL,
      password: process.env.USER_PASSWORD,
    }
  }
  try {
    let options = new chrome.Options();
    driver = await new Builder()
      .setChromeOptions(options)
      .forBrowser('chrome')
      .build();
    await driver.get(configs.shopUrls.login);
    await driver.findElement(By.css('#username')).sendKeys(configs.user.email);
    await driver.findElement(By.css('#password')).sendKeys(configs.user.password);
    await driver.findElement(By.css('.woocommerce-form-login__submit')).click();
    await driver.get(configs.shopUrls.product);
    await driver.findElement(By.css('.single_add_to_cart_button')).click();
    await driver.get(configs.shopUrls.order);
    await driver.sleep(5 * 1000);
    await driver.findElement(By.css('.payment_method_getnet-redirect')).click();
    await driver.findElement(By.css('[name=woocommerce_checkout_place_order]')).click();
    await driver.sleep(10 * 1000);
    await driver.findElement(By.css('.pm-button-paypal')).click();
    await driver.findElement(By.css('#btn-submit-payment')).click();
    await driver.sleep(15 * 1000);
    await driver.findElement(By.css('#email')).sendKeys('paypal.buyer3@getneteurope.com');
    await driver.findElement(By.css('.actionContinue')).click();
    await driver.sleep(5 * 1000);
    await driver.findElement(By.css('#password')).sendKeys('Getnetbuyer');
    await driver.findElement(By.css('#btnLogin')).click();
    await driver.sleep(10 * 1000);
    await driver.findElement(By.css('#payment-submit-btn')).click();
  } catch (error) {
    console.log(error)
  } finally {
    // await driver.quit();
  }
})();
