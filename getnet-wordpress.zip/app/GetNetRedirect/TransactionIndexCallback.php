<?php

namespace App\GetNetRedirect;

use App\Constants;

class TransactionIndexCallback
{
    public function __construct()
    {
        //
    }

    public function show()
    {
        global $wpdb;
        $tableName = $wpdb->prefix . Constants::TABLENAME;
        $results = $wpdb->get_results(
            "SELECT id
                , url
                , req_headers
                , req_body
                , res_code
                , res_headers
                , res_body
                , order_id
                , created_at
                , updated_at
            FROM {$tableName}
            WHERE 1
            ORDER BY id DESC"
        );
        echo "<div class=\"wrap\">
            <h1>Transactions</h1>
            <table>
                <tr>
                    <th>id</th>
                    <th>url</th>
                    <th>req_headers</th>
                    <th>req_body</th>
                    <th>res_code</th>
                    <th>res_headers</th>
                    <th>res_body</th>
                    <th>order_id</th>
                    <th>created_at</th>
                    <th>updated_at</th>
                </tr>
                <tbody>
        ";
        foreach ($results as $row) {
            echo "
                <tr>
                    <td>{$row->id}</td>
                    <td>{$row->url}</td>
                    <td>{$row->req_headers}</td>
                    <td>{$row->req_body}</td>
                    <td>{$row->res_code}</td>
                    <td>{$row->res_headers}</td>
                    <td>{$row->res_body}</td>
                    <td>{$row->order_id}</td>
                    <td>{$row->created_at}</td>
                    <td>{$row->updated_at}</td>
                </tr>
            ";
        }
        echo "
                </tbody>
            </table>
        </div>";
    }
}
