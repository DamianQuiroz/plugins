<?php

namespace App\Library;

use App\Constants;

class HttpClient
{
    /**
     * Base URI
     *
     * @var string
     */
    public $baseUri;

    /**
     * Headers array
     *
     * @var array
     */
    public $headers;

    public function __construct($baseUri, $headers = [
            'content-type' => 'application/json',
            'accept' => 'application/json',
        ])
    {
        $this->baseUri = $baseUri;
        $this->headers = $headers;
    }

    /**
     * Add the given key/value to the headers array
     *
     * @param string $key
     * @param mixed $val
     * @return array
     */
    protected function addToHeaders($key, $val)
    {
        $this->headers = array_merge([$key => $val], $this->headers);
        return $this->headers;
    }

    /**
     * Get the URL for the endpoint
     *
     * @param string $endpoint
     * @return string
     */
    protected function getUrl($endpoint): string
    {
        return "{$this->baseUri}{$endpoint}";
    }

    /**
     * Makes the request
     *
     * @param string $endpoint
     * @param string $method
     * @param array $payload
     * @return mixed
     */
    protected function request($endpoint, $payload)
    {
        $url = $this->getUrl($endpoint);
        $params = [
            'body' => wp_json_encode($payload),
            'headers' => $this->headers,
            'timeout' => 60,
            'redirection' => 5,
            'blocking' => true,
            'httpversion' => '1.0',
            'sslverify' => false,
            'data_format' => 'body',
        ];

        global $wpdb;
        $tableName = $wpdb->prefix . Constants::TABLENAME;
        $wpdb->insert($tableName, [
            'url' => $url,
            'req_headers' => json_encode($params['headers']),
            'req_body' => json_encode($payload),
        ]);
        $lastId = $wpdb->insert_id;
        $response = wp_remote_post($url, $params);
        $responseBody = json_decode(wp_remote_retrieve_body($response), true);
        $wpdb->update($tableName, [
            'res_code' =>  wp_remote_retrieve_response_code($response),
            'res_headers' => wp_remote_retrieve_headers($response),
            'res_body' => wp_remote_retrieve_body($response)
        ], [
            'id' => $lastId
        ]);
        return $responseBody;
    }

    /**
     * Sets the bearer token
     *
     * @param string $token
     * @param string $bearerLabel
     * @return string
     */
    protected function setBearerAuth($token, $bearerLabel = 'Bearer')
    {
        $this->addToHeaders('Authorization', "${bearerLabel} {$token}");
        return $this->headers['Authorization'];
    }
}
