<?php

namespace App;

use App\GetNetRedirect\ActivationCallback;
use App\GetNetRedirect\TransactionIndexCallback;

class Kernel
{
    public static $instance;

    /**
     * Activation hook. Runs when the plugin is activated
     *
     * @return void
     */
    private function addActivationHook()
    {
        register_activation_hook(PLUGIN_FILE, function () {
            ActivationCallback::execute();
        });
    }

    /**
     * Adds the payment gateway to the list of gateways
     *
     * @return void
     */
    private function addPaymentGatewayToList()
    {
        add_filter('woocommerce_payment_gateways', function ($gateways) {
            $gateways[] = 'App\\GetNetRedirectGateway';
            return $gateways;
        });
    }

    /**
     * Adds the menu action
     *
     * @return void
     */
    private function addMenuAction()
    {
        add_action('admin_menu', function () {
            add_menu_page(
                __('Transactions', 'wc_getnet_redirect'),
                __('Transactions', 'wc_getnet_redirect'),
                'manage_woocommerce',
                'gnr_transactions',
                function () {
                    $transactionIndex = new TransactionIndexCallback();
                    $transactionIndex->show();
                },
                'dashicons-admin-site'
            );
        });
    }

    /**
     * Initializes the plugin
     *
     * @return \App\Kernel
     */
    public static function init()
    {
        if (!isset(self::$instance)) {
            self::$instance = new Kernel();
            self::$instance->setup();
        }
        return self::$instance;
    }

    /**
     * Initializes the gateway
     *
     * @return void
     */
    private function iniatilizeGateway()
    {
        add_action(
            'plugins_loaded',
            function () {
                (new GetNetRedirectGateway());
            },
            11
        );
    }

    /**
     * Setups the plugin
     *
     * @return void
     */
    public function setup()
    {
        $this->addActivationHook();
        $this->addMenuAction();
        $this->addPaymentGatewayToList();
        $this->iniatilizeGateway();
    }

    /**
     * Muestra la lista de transacciones
     *
     * @return void
     */
    public function showTransactions()
    {
        return '<h1>Hello, it\'s monday</h1>';
    }
}
