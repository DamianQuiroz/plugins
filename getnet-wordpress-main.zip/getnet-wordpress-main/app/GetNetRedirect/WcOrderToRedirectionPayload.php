<?php

namespace App\GetNetRedirect;

use App\Constants;

class WcOrderToRedirectionPayload
{
    /**
     * Retrieves the order formatted as a redirection payload
     *
     * @param mixed $order
     * @param mixed $merchantAccountResolverCategory
     * @return array
     */
    public static function getPayload($order, $merchantAccountResolverCategory, $creditorId)
    {
        $result = [];
        $requestId = current_time('YmdHis') . $order->get_id();
        $result['payment'] = [
            'merchant-account-resolver-category' => $merchantAccountResolverCategory,
            'request-id' => $requestId,
            'transaction-type' => 'auto-sale',
            'requested-amount' => [
                'value' => $order->get_total(),
                'currency' => $order->get_currency(),
            ],
            'three-d' => [
                'attempt-three-d' => "true",
                'version' => "2.2"
            ],
            'account-holder' => [
                'merchant-crm-id' => $order->get_customer_id(),
                'first-name' => $order->get_billing_first_name(),
                'last-name' => $order->get_billing_last_name(),
                'phone' => $order->get_billing_phone(),
                'mobile-phone' => null,
                'work-phone' => null,
                'email' => $order->get_billing_email(),
                'address' => [
                    'street1' => $order->get_billing_address_1(),
                    'street2' => $order->get_billing_address_2(),
                    'street3' => null,
                    'city' => $order->get_billing_city(),
                    'postal-code' => $order->get_billing_postcode(),
                    'state' => $order->get_billing_state(),
                    'country' => $order->get_billing_country(),
                ]
            ],
            'shipping' => [
                'shipping-method' => $order->get_shipping_method(),
                'email' => $order->get_billing_email(),
                'address' => [
                    'street1' => $order->get_shipping_address_1(),
                    'street2' => $order->get_shipping_address_2(),
                    'street3' => null,
                    'city' => $order->get_shipping_city(),
                    'postal-code' => $order->get_shipping_postcode(),
                    'state' => $order->get_shipping_state(),
                    'country' => $order->get_shipping_country(),
                ]
            ],
            'mandate' => [
                'mandate-id' => $order->get_id()
            ],
            'order-number' => $order->get_id(),
            'creditor-id' => $creditorId,
            'descriptor' => $order->get_id(),
            'locale' => get_user_locale(),
            'ip-address' => "127.0.0.1",
            'success-redirect-url' => site_url() . '/wc-api/getnet-redirect-callback',
            'fail-redirect-url' => site_url() . '/wc-api/getnet-redirect-callback',
            'cancel-redirect-url' => site_url() . '/wc-api/getnet-redirect-callback',
        ];

        $orderItems = [];
        foreach ($order->get_items() as $item) {
            $itemInfo = [
                'amount' => [
                    'currency' => $order->get_currency(),
                    'value' => $item->get_total(),
                ],
                'article-number' => $item->get_product_id(),
                'description' => null,
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'tax-amount' => [
                    'currency' => $order->get_currency(),
                    'value' => $item->get_subtotal_tax(),
                ],
                'tax-rate' => null,
            ];
            $orderItems[] = $itemInfo;
        }

        if ($order->get_shipping_total() > 0) {
            $orderItems[] = [
                'amount' => [
                    'currency' => $order->get_currency(),
                    'value' => $order->get_shipping_total()
                ],
                'article-number' => "SHIPPING",
                'description' => "SHIPPING",
                'name' => "SHIPPING",
                'quantity' => 1,
                'tax-amount' => [
                    'currency' => $order->get_currency(),
                    'value' => 0
                ],
                'tax-rate' => 0
            ];
        }

        $result['payment']['order-items']['order-item'] = $orderItems;

        // Remove order items from zloty request
        if ($order->get_currency() == Constants::ZLOTY_ISO_CODE) {
            unset($result['payment']['order-items']);
        }

        return $result;
    }
}
