<?php

namespace App\GetNetRedirect;

use App\Constants;

class WcOrderRefundedPayload
{
    /**
     * Retrieve the payload for cancellation
     *
     * @return array
     */
    public static function getPayload(
        $order,
        $settings,
        $processedBy,
        $purchaseRequestId,
        $purchasePaymentMethod,
        $purchaseTransactionType,
        $merchantAccountId,
        $transactionId
    ) {
        $payload = [];
        $requestId = current_time('YmdHis') . $order->get_id();
        $transactionType = null;

        // Transaction Type Logic
        switch ($purchasePaymentMethod) {
            case Constants::PURCHASE_METHOD_ALIPAY_XBORDER:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_DEBIT;
                }
                break;
            case Constants::PURCHASE_METHOD_BLIK:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_CREDITCARD:
                if ($purchaseTransactionType === Constants::TX_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                if ($purchaseTransactionType === Constants::TX_PURCHASE) {
                    $transactionType = Constants::TX_REFUND_PURCHASE;
                }
                break;
            case Constants::PURCHASE_METHOD_IDEAL:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_CREDIT;
                }
                break;
            case Constants::PURCHASE_METHOD_P24:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_REQUEST;
                }
                break;
            case Constants::PURCHASE_METHOD_PAYPAL:
                if ($purchaseTransactionType === Constants::TX_AUTHORIZATION) {
                    $transactionType = Constants::TX_REFUND_CAPTURE;
                }
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_REFUND_DEBIT;
                }
                break;
            case Constants::PURCHASE_METHOD_POI_PIA:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_SEPA_CREDIT:
                // NO SUPPORT
                break;
            case Constants::PURCHASE_METHOD_SEPA_DIRECT_DEBIT:
                if ($purchaseTransactionType === Constants::TX_AUTHORIZATION) {
                    $transactionType = Constants::TX_CREDIT;
                }
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_CREDIT;
                }
                break;
            case Constants::PURCHASE_METHOD_SOFORT:
                if ($purchaseTransactionType === Constants::TX_DEBIT) {
                    $transactionType = Constants::TX_CREDIT;
                }
                break;
        }

        if ($transactionType === null) {
            throw new \Exception("Purchase payment method {$purchasePaymentMethod} is not supported for refund");
        }

        $payload['payment'] = [
            'merchant-account-id' => [
                'value' => $merchantAccountId
            ],
            'requested-amount' => [
                'value' => $order->get_total(),
                'currency' => $order->get_currency(),
            ],
            'request-id' => $requestId,
            'transaction-type' => $transactionType,
            'parent-transaction-id' => $transactionId
        ];
        return $payload;
    }
}
