<?php

namespace App\GetNetRedirect;

use App\Constants;

class ActivationCallback
{
    /**
     * Creates tables
     *
     * @return void
     */
    public function createTables()
    {
        global $wpdb;
        $charsetCollate = $wpdb->get_charset_collate();
        $tableName = $wpdb->prefix . Constants::TABLENAME;

        $sql = "CREATE TABLE $tableName (
            id bigint unsigned not null auto_increment primary key,
            url varchar(512) null,
            req_headers longtext null,
            req_body longtext null,
            res_code int null,
            res_headers longtext null,
            res_body longtext null,
            order_id bigint unsigned null,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) $charsetCollate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public static function execute()
    {
        $act = new ActivationCallback();
        return $act->processActivation();
    }

    /**
     * Process the activation
     *
     * @return void
     */
    public function processActivation()
    {
        $this->createTables();
    }
}
