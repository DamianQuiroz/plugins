<?php

class Environment
{
    const PRODUCTION = 'production';
    const DEVELOPMENT = 'development';
}