<?php

class GetnetErrorModuleFrontController extends ModuleFrontController
{
    /**
     * Maneja el callback de error desde getnet.
     * @return void
     */
    public function postProcess()
    {
        $this->errors[] = $this->l(
            'An error ocurred while processing your payment, please try again or select a different payment method.'
        );
        $this->redirectWithNotifications($this->getUrl('index.php?controller=order&step=4'));
    }

    /**
     * @param $url
     * @param $base_uri
     * @param $link
     * @return mixed|string
     */
    public function getUrl($url, $base_uri = __PS_BASE_URI__, $link = null)
    {
        if (!$link) {
            $link = Context::getContext()->link;
        }

        if (strpos($url, 'http://') === false && strpos($url, 'https://') === false && $link) {
            if (strpos($url, $base_uri) === 0) {
                $url = substr($url, strlen($base_uri));
            }
            if (strpos($url, 'index.php?controller=') !== false && strpos($url, 'index.php/') == 0) {
                $url = substr($url, strlen('index.php?controller='));
                if (Configuration::get('PS_REWRITING_SETTINGS')) {
                    $url = Tools::strReplaceFirst('&', '?', $url);
                }
            }

            $explode = explode('?', $url);
            $use_ssl = !empty($url);
            $url = $link->getPageLink($explode[0], $use_ssl);
            if (isset($explode[1])) {
                $url .= '?' . $explode[1];
            }
        }

        return $url;
    }
}