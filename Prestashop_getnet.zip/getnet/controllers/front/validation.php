<?php

class GetnetValidationModuleFrontController extends ModuleFrontController
{
    /**
     * Procesa los datos enviados por la forma de pago
     */
    public function postProcess()
    {
        if (!empty($_POST)) {
            // Retrieve the response from the get net post
            $responseBase64 = $_REQUEST['response-base64'];
            $responseBase64Decoded = base64_decode($responseBase64);
            $contentParsed = json_decode($responseBase64Decoded, true);

            $this->log('===========================================================================');
            $this->log(json_encode($contentParsed));
            $this->log('===========================================================================');

            // Retrieve the payment state
            $transaction_state = $contentParsed['payment']['transaction-state'];

            if ($transaction_state == 'success') {
                // Process success
                $this->process_payment($contentParsed, 'success');
            } else if ($transaction_state == 'failed') {
                // Process the failed payment
                $this->process_payment($contentParsed, 'failed');
            } else if ($transaction_state == 'cancel') {
                $this->errors[] = $this->l('The transaction was cancelled.');
                $this->redirectWithNotifications('index.php?controller=order&step=1');
            }
        } else {
            // Redirect the customer with errors
            $this->errors[] = $this->l('The was an error processing your order, please try again or select a different payment method..');
            $this->redirectWithNotifications($this->getUrl('index.php?controller=order&step=1'));
        }
    }

    /**
     * Set a success order state for the payment and validates it
     * 
     * @param Array $parsedContent
     * @param String $state
     */
    public function process_payment($contentParsed, $state)
    {
        // Retrieve the transaction_id to retrive the order_id
        $request_id = $contentParsed['payment']['request-id'];
        $cart_id = explode('C', $request_id)[1];

        // Retrieve the request amount truncated
        $payment_value = number_format($contentParsed['payment']['requested-amount']['value'], 2);

        // Create the cart according to the id
        $cart = new Cart($cart_id);
        $this->context->cart = $cart;
        // Set the cart to the context
        $cart = $this->context->cart;

        //Verify module integrity
        if (
            !$this->module->active || $cart->id_customer == 0 || $cart->id_address_delivery == 0
            || $cart->id_address_invoice == 0
        ) {
            $this->errors[] = $this->l('The cart is invalid');
            $this->redirectWithNotifications($this->getUrl('index.php?controller=order&step=1'));
        }

        // Verify the customer context
        $customer = new Customer($cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            $this->errors[] = $this->l('The client is not valid.');
            $this->redirectWithNotifications($this->getUrl('index.php?controller=order&step=1'));
        }

        // Log user back
        $this->logUserBack($customer);

        // Verigy payment value
        if (number_format((float) $this->context->cart->getOrderTotal(true, Cart::BOTH), 2) != $payment_value) {
            $this->errors[] = $this->l('The payed amount doesnt match the cart amount to be payed.');
            $this->redirectWithNotifications($this->getUrl('index.php?controller=order&step=1'));
        }

        // Place order with the data
        $this->module->validateOrder(
            (int) $this->context->cart->id,
            $state == 'success' ? Configuration::get('PS_OS_PAYMENT') : Configuration::get('PS_OS_ERROR'),
            (float) $this->context->cart->getOrderTotal(true, Cart::BOTH),
            $this->module->displayName,
            null,
            null,
            (int) $this->context->currency->id,
            false,
            $customer->secure_key
        );
        $this->log('previo al success');

        if ($state == 'success') {
            // Set the transaction id to the order payment 
            $new_order = new Order((int)$this->module->currentOrder);
            $payment = $new_order->getOrderPaymentCollection();
            if (isset($payment[0])) {
                $payment[0]->transaction_id = json_encode([
                    'transaction-id' => $contentParsed['payment']['transaction-id'],
                    'merchant-account-id' => $contentParsed['payment']['merchant-account-id']['value'],
                    'transaction-type' => $contentParsed['payment']['transaction-type']
                ]);
                $payment[0]->save();
            }
            
            // Redirect the customer to the order confirmation
            $this->success[] = $this->l('The payment was successfull.');
            $this->redirectWithNotifications($this->getUrl('index.php?controller=order-confirmation&id_cart=' . (int)$cart->id . '&id_module=' . (int)$this->module->id . '&id_order=' . $this->module->currentOrder . '&key=' . $customer->secure_key));
        } else {
            // Redirect the customer with errors
            $this->errors[] = $this->l('The was an error processing your order, please try again or select a different payment method.');
            $this->redirectWithNotifications($this->getUrl('index.php?controller=order&step=1'));
        }
    }

    /**
     * Log user back into session after los cookies
     * 
     * @param $customer
     */
    public function logUserBack($customer)
    {
        $customer->logged = 1;
        $this->context->customer = $customer;
        $this->context->cookie->id_customer = (int) $customer->id;
        $this->context->cookie->customer_lastname = $customer->lastname;
        $this->context->cookie->customer_firstname = $customer->firstname;
        $this->context->cookie->logged = 1;
        $this->context->cookie->check_cgv = 1;
        $this->context->cookie->is_guest = false;
        $this->context->cookie->passwd = $customer->passwd;
        $this->context->cookie->email = $customer->email;
        $this->context->cookie->registerSession(new CustomerSession());

        return null;
    }

    /**
     * Retrieve the url depending on the context
     */
    public function getUrl($url, $base_uri = __PS_BASE_URI__, $link = null)
    {
        if (!$link) {
            $link = Context::getContext()->link;
        }

        if (strpos($url, 'http://') === false && strpos($url, 'https://') === false && $link) {
            if (strpos($url, $base_uri) === 0) {
                $url = substr($url, strlen($base_uri));
            }
            if (strpos($url, 'index.php?controller=') !== false && strpos($url, 'index.php/') == 0) {
                $url = substr($url, strlen('index.php?controller='));
                if (Configuration::get('PS_REWRITING_SETTINGS')) {
                    $url = Tools::strReplaceFirst('&', '?', $url);
                }
            }

            $explode = explode('?', $url);
            $use_ssl = !empty($url);
            $url = $link->getPageLink($explode[0], $use_ssl);
            if (isset($explode[1])) {
                $url .= '?' . $explode[1];
            }
        }

        return $url;
    }

    public static function log($txt)
    {
        $myfile = fopen('modules/getnet/log.txt', "a") or die("Unable to open file!");
        fwrite($myfile,  date("Y-m-d") . " Log : " . $txt . " \n");
        fclose($myfile);
    }
}
