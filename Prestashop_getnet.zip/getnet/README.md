# Getnet PrestaShop Module
[![License](https://img.shields.io/badge/license-MIT-brightgreen.svg)](https://www.getneteurope.com/?CHANGE_LINK)
[![PHP ^7.1](https://img.shields.io/badge/php-%5E7.1-brightgreen.svg)](http://www.php.net)
[![PrestaShop v1.7.6.7](https://img.shields.io/badge/PrestaShop-v1.7.8.6-brightgreen.svg)](https://www.prestashop.com/es)

***
## Installation

### Requirements

- Active PrestaShop v1.7.6.7 Installation

### Installing the module

1. To download the module, go to [RELEASES](https://www.getneteurope.com/?CHANGE_LINK) and download the latest release.
2. Enter your PrestaShop admin interface.
3. Navigate to the modules manager interface (Modules/Modules manager).
4. Click on the Upload a module button
![Upload a module button](/docs/assets/upload_a_module_button.jpg)
5. On the Upload a module modal browse for the downloaded file (on step 1)
![Upload a module modal](/docs/assets/upload_a_module_modal.jpg)
6. The installation process will be triggered automatically. When it finishes click on the Configure.
![Upload a module success](/docs/assets/upload_a_module_success.jpg)

## Configuration

To access the configuration options of the plugin go to the modulse manager interface and navigate to the category "Payment". Select "Configure" option.

![Configure button](/docs/assets/configure-button.jpg)

#### Options

Merchant Account ID: Enter the Merchant Account ID (MAID) provided.
Username: Enter the username credentials provided.
Password: Enter the password credentials provided.
Creditor ID: In case you will be using SEPA DD as a payment option. Enter the Creditor ID provided.

## Cancel an order

1. Go to the Orders interface (Orders/orders).
2. Select the order.
3. Change the order status to Canceled.

![Cancel button](/docs/assets/prestashop-payment-status-cancel.jpg)

## Refund an order

1. Go to the Orders interface (Orders/orders).
2. Select the order.
3. Change the order status to Refunded.

![Refunded button](/docs/assets/prestashop-payment-status-cancel.jpg)
