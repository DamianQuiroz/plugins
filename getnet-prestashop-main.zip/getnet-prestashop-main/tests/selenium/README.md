# How to run the tests

1. Install node packages (from the root folder)

```shell
npm install
```

2. Execute the test

```shell
node tests\prestashop\cc-purchase.js
```