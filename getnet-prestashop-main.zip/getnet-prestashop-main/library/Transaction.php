<?php

class Transaction
{
    public const PURCHASE_METHOD_ALIPAY_XBORDER = 'alipay-xborder';
    public const PURCHASE_METHOD_BLIK = 'blik';
    public const PURCHASE_METHOD_CREDITCARD = 'creditcard';
    public const PURCHASE_METHOD_IDEAL = 'ideal';
    public const PURCHASE_METHOD_P24 = 'p24';
    public const PURCHASE_METHOD_PAYPAL = 'paypal';
    public const PURCHASE_METHOD_POI_PIA = 'wiretransfer';
    public const PURCHASE_METHOD_SEPA_CREDIT = 'sepacredit';
    public const PURCHASE_METHOD_SEPA_DIRECT_DEBIT = 'sepadirectdebit';
    public const PURCHASE_METHOD_SOFORT = 'sofortbanking';
    public const TX_AUTHORIZATION = 'authorization';
    public const TX_CAPTURE_AUTHORIZATION = 'capture-authorization';
    public const TX_CREDIT = 'credit';
    public const TX_DEBIT = 'debit';
    public const TX_PURCHASE = 'purchase';
    public const TX_REFUND_CAPTURE = 'refund-capture';
    public const TX_REFUND_DEBIT = 'refund-debit';
    public const TX_REFUND_PURCHASE = 'refund-purchase';
    public const TX_REFUND_REQUEST = 'refund-request';
    public const TX_VOID_AUTHORIZATION = 'void-authorization';
    public const TX_VOID_PURCHASE = 'void-purchase';

    /**
     * Get the transaction type for the given operation
     * @param string $transactionData
     * @param string $operation
     * @return mixed
     */
    public static function getTransaction($operation, $purchasePaymentMethod, $purchaseTransactionType)
    {
        $transaction = null;
        if ($operation == 'void') {
            $transaction = Transaction::getCancelledTransaction($purchasePaymentMethod, $purchaseTransactionType);
        } elseif ($operation == 'refund') {
            $transaction = Transaction::getRefundTransaction($purchasePaymentMethod, $purchaseTransactionType);
        }
        return $transaction;
    }

    /**
     * Get the cancellation type for the given payment method and purchase transaction type
     *
     * @param string $purchasePaymentMethod
     * @param string $purchaseTransactionType
     * @return mixed
     */
    public static function getCancelledTransaction($purchasePaymentMethod, $purchaseTransactionType)
    {
        $transactionType = null;
        switch ($purchasePaymentMethod) {
            case Transaction::PURCHASE_METHOD_ALIPAY_XBORDER:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_BLIK:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_CREDITCARD:
                if ($purchaseTransactionType === Transaction::TX_AUTHORIZATION) {
                    $transactionType = Transaction::TX_VOID_AUTHORIZATION;
                }
                break;
            case Transaction::PURCHASE_METHOD_IDEAL:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_P24:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_PAYPAL:
                if ($purchaseTransactionType === Transaction::TX_AUTHORIZATION) {
                    $transactionType = Transaction::TX_VOID_AUTHORIZATION;
                }
                break;
            case Transaction::PURCHASE_METHOD_POI_PIA:
                if ($purchaseTransactionType === Transaction::TX_AUTHORIZATION) {
                    $transactionType = Transaction::TX_VOID_AUTHORIZATION;
                }
                break;
            case Transaction::PURCHASE_METHOD_SEPA_CREDIT:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_SEPA_DIRECT_DEBIT:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_SOFORT:
                // NO SUPPORT
                break;
        }
        return $transactionType;
    }

    /**
     * Get the refund type for the given payment method and purchase transaction type
     *
     * @param string $purchasePaymentMethod
     * @param string $purchaseTransactionType
     * @return mixed
     */
    public static function getRefundTransaction($purchasePaymentMethod, $purchaseTransactionType)
    {
        $transactionType = null;
        // Transaction Type Logic
        switch ($purchasePaymentMethod) {
            case Transaction::PURCHASE_METHOD_ALIPAY_XBORDER:
                if ($purchaseTransactionType === Transaction::TX_DEBIT) {
                    $transactionType = Transaction::TX_REFUND_DEBIT;
                }
                break;
            case Transaction::PURCHASE_METHOD_BLIK:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_CREDITCARD:
                if ($purchaseTransactionType === Transaction::TX_AUTHORIZATION) {
                    $transactionType = Transaction::TX_REFUND_CAPTURE;
                }
                if ($purchaseTransactionType === Transaction::TX_PURCHASE) {
                    $transactionType = Transaction::TX_REFUND_PURCHASE;
                }
                break;
            case Transaction::PURCHASE_METHOD_IDEAL:
                if ($purchaseTransactionType === Transaction::TX_DEBIT) {
                    $transactionType = Transaction::TX_CREDIT;
                }
                break;
            case Transaction::PURCHASE_METHOD_P24:
                if ($purchaseTransactionType === Transaction::TX_DEBIT) {
                    $transactionType = Transaction::TX_REFUND_REQUEST;
                }
                break;
            case Transaction::PURCHASE_METHOD_PAYPAL:
                if ($purchaseTransactionType === Transaction::TX_AUTHORIZATION) {
                    $transactionType = Transaction::TX_REFUND_CAPTURE;
                }
                if ($purchaseTransactionType === Transaction::TX_DEBIT) {
                    $transactionType = Transaction::TX_REFUND_DEBIT;
                }
                break;
            case Transaction::PURCHASE_METHOD_POI_PIA:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_SEPA_CREDIT:
                // NO SUPPORT
                break;
            case Transaction::PURCHASE_METHOD_SEPA_DIRECT_DEBIT:
                if ($purchaseTransactionType === Transaction::TX_AUTHORIZATION) {
                    $transactionType = Transaction::TX_CREDIT;
                }
                if ($purchaseTransactionType === Transaction::TX_DEBIT) {
                    $transactionType = Transaction::TX_CREDIT;
                }
                break;
            case Transaction::PURCHASE_METHOD_SOFORT:
                if ($purchaseTransactionType === Transaction::TX_DEBIT) {
                    $transactionType = Transaction::TX_CREDIT;
                }
                break;
        }
        return $transactionType;
    }
}
