<?php

class GnrRequest extends ObjectModel
{
    public $id_request;
    public $url;
    public $req_headers;
    public $req_body;
    public $res_code;
    public $res_headers;
    public $res_body;

    public static $definition = [
        'table' => 'gnr_request',
        'primary' => 'id_request',
        'multilang' => false,
        'fields' => array(
            'id_request' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'url' => ['type' => self::TYPE_STRING, 'required' => false],
            'req_headers' => ['type' => self::TYPE_STRING, 'required' => false],
            'req_body' => ['type' => self::TYPE_STRING, 'required' => false],
            'res_code' => ['type' => self::TYPE_STRING, 'required' => false],
            'res_headers' => ['type' => self::TYPE_STRING, 'required' => false],
            'res_body' => ['type' => self::TYPE_STRING, 'required' => false],
            'order_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
        )
    ];
}
