<?php

class OrderStatus
{
    const ORDER_STATUS_ID_CANCELED = 6;
    const ORDER_STATUS_ID_REFUNDED= 7;
    const ORDER_STATUS_ID_PAYMENT_ACCEPTED= 2;
}