<?php

class SupportedCurrency
{
    const EURO = 'EUR';
    const USD_DOLLARS = 'USD';
    const ZLOTY = 'PLN';
}
