<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once _PS_ROOT_DIR_ . '/modules/getnet/constants/SupportedCurrency.php';
include_once _PS_ROOT_DIR_ . '/modules/getnet/constants/Environment.php';
include_once _PS_ROOT_DIR_ . '/modules/getnet/constants/OrderStatus.php';
require_once _PS_ROOT_DIR_ . '/modules/getnet/library/GnrRequest.php';
include_once _PS_ROOT_DIR_ . '/modules/getnet/library/Transaction.php';

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

class Getnet extends PaymentModule
{
    /**
     * Getnet constructor.
     *
     * Set the information about this module.
     */
    public function __construct()
    {
        $this->name = 'getnet';
        $this->tab = 'payments_gateways';
        $this->version = '1.0';
        $this->author = 'Getnet.';
        $this->controllers = array('payment', 'validation');
        $this->bootstrap = true;
        $this->displayName = $this->l('Getnet');
        $this->description = $this->l('Modulo de integración de pago Getnet.');
        $this->confirmUninstall = $this->l('¿Estás seguro que deseas desinstalar este módulo?');
        $this->ps_versions_compliancy = array('min' => '1.7.0', 'max' => _PS_VERSION_);

        // Defines the module environment, applies the urls depending on the selected environment.
        switch (Tools::getValue('ENVIRONMENT', Configuration::get('ENVIRONMENT'))) {
            case Environment::DEVELOPMENT:
                $this->payment_url = 'https://paymentpage-test.getneteurope.com/api/payment/register';
                $this->api_url = 'https://api-test.getneteurope.com/engine/rest/payments/';
                break;
            case Environment::PRODUCTION:
                $this->payment_url = 'https://paymentpage-test.getneteurope.com/api/payment/register';
                $this->api_url = 'https://api-prod.getneteurope.com/engine/rest/payments/';
                break;
            default:
                $this->payment_url = 'https://paymentpage-test.getneteurope.com/api/payment/register';
                $this->api_url = 'https://api-test.getneteurope.com/engine/rest/payments/';
        }

        parent::__construct();
    }

    /**
     * Install this module and register the following Hooks:
     *
     * @return bool
     */
    public function install()
    {
        return parent::install()
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn')
            && $this->registerHook('actionOrderStatusUpdate')
            && $this->installTab('AdminGetNetTransactions', $this->l('Getnet Transactions'), 'AdminParentPayment')
            && $this->installDatabaseTables();
    }

    /**
     * Install tab in the Admin Page
     *
     * @param string $yourControllerClassName the name of the controller in 'controllers/admin/{name}Controller'
     * @param string $yourTabName the name that will appear on the menu list
     * @param string $tabParentControllerName the name
     * @return boolean
     */
    public function installTab($yourControllerClassName, $yourTabName, $tabParentControllerName = null)
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = $yourControllerClassName;
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $yourTabName;
        }
        if ($tabParentControllerName) {
            $tab->id_parent = (int)SymfonyContainer::getInstance()
                ->get('prestashop.core.admin.tab.repository')
                ->findOneIdByClassName($tabParentControllerName);
        } else {
            $tab->id_parent = 0;
        }
        $tab->module = $this->name;
        $tab->add();
        return true;
    }

    /**
     * Install the table for transactions
     *
     * @return boolean
     */
    public function installDatabaseTables()
    {
        $sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'gnr_request`;
        CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'gnr_request` (
            id_request bigint unsigned not null auto_increment primary key,
            url varchar(512) null,
            req_headers longtext null,
            req_body longtext null,
            res_code int null,
            res_headers longtext null,
            res_body longtext null,
            order_id bigint unsigned null,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;';

        foreach ($sql as $query) {
            if (Db::getInstance()->execute($query) == false) {
                return false;
            }
        }
        return true;
    }

    /**
     * Uninstall this module and remove it from all hooks
     *
     * @return bool
     */
    public function uninstall()
    {
        return parent::uninstall();
    }

    /* #region  paymentOptionsHook */
    /**
     * Display this module as a payment option during the checkout.
     *
     * @param array $params
     * @return array|void
     * @throws Exception
     */
    public function hookPaymentOptions($params)
    {
        /*
         * Verify if this module is active
         */
        if (!$this->active) {
            return;
        }

        /**
         * Form action URL. The form data will be sent to the
         * validation controller when the user finishes
         * the order process.
         */
        $formAction = $this->context->link->getModuleLink($this->name, 'validation', array(), true);

        /**
         * Assign the url form action to the template var $action
         */
        $this->smarty->assign(['action' => $formAction]);

        /**
         * Set the payment options to the payment hook
         */
        $payment_options = [];

        // If the getnet url is generated correclty the option is displayed
        $getnetPaymentAction = $this->retrieveGetnetAction();
        if ($getnetPaymentAction != null) {
            $payment_options[] = $this->retrieveGetnetPaymentOption($getnetPaymentAction);
        }

        return $payment_options;
    }

    /**
     *  Retrieve the Getnet payment option.
     *
     * @param $getnetPaymentAction
     * @return \PrestaShop\PrestaShop\Core\Payment\PaymentOption
     */
    public function retrieveGetnetPaymentOption($getnetPaymentAction)
    {
        /**
         * Create a PaymentOption object containing the necessary data
         * to display this module in the checkout
         */
        $newOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption;
        $newOption->setModuleName($this->displayName)
            ->setCallToActionText($this->l('Pagar con Getnet'))
            ->setForm($this->getPaymentForm($getnetPaymentAction));

        return $newOption;
    }

    /**
     * Retrieve the form according to the getnet client
     *
     * @param $getnetPaymentAction
     * @return string $htmlString
     */
    public function getPaymentForm($getnetPaymentAction)
    {
        return '<form
                    method="GET"
                    action="' . $getnetPaymentAction['url'] . '"
                >
                    <input type="hidden" name="wPaymentToken" value="' . $getnetPaymentAction['token'] . '"/>
                </form>';
    }

    /**
     * Retrieve the getnet token according to the user and card information.
     *
     * @return array|null
     * @throws Exception
     */
    public function retrieveGetnetAction()
    {
        // Retrieve the call back link
        $callback = $this->context->link->getModuleLink($this->name, 'validation', array(), true);
        $error_callback = $this->context->link->getModuleLink($this->name, 'validation', array(), true);

        // Retrieve the necessary order values
        $currency_iso_code = $this->context->currency->iso_code;
        $order_value_as_string = '' . (float)$this->context->cart->getOrderTotal(true, Cart::BOTH);

        // Retrieve the customer
        $customer = new Customer($this->context->cart->id_customer);
        // Retrieve the address
        $address = new Address($this->context->cart->id_address_delivery);
        // Retrieve the state
        $state = new State($address->id_state);
        // Retrieve the country
        $country = new Country($address->id_country);
        // Retrieve the carrier
        $carrier = new Carrier($this->context->cart->id_carrier);

        $products = [];

        foreach ($this->context->cart->getProducts() as $product) {
            $products[] = [
                'amount' => [
                    'currency' => $currency_iso_code,
                    'value' => $product['total_wt']
                ],
                'article-number' => $product['id_product'],
                'description' => $product['description_short'],
                'name' => $product['name'],
                'quantity' => $product['quantity'],
                'tax-amount' => [
                    'currency' => $currency_iso_code,
                    'value' => $product['rate'] / 100
                ],
                'tax-rate' => $product['rate']
            ];
        }

        // Evaluate the append of the shipping cost
        $shippingCost = $this->context->cart->getPackageShippingCost();
        if ($shippingCost > 0) {
            $products[] = [
                'amount' => [
                    'currency' => $currency_iso_code,
                    'value' => $shippingCost
                ],
                'article-number' => "SHIPPING",
                'description' => "SHIPPING",
                'name' => "SHIPPING",
                'quantity' => 1,
                'tax-amount' => [
                    'currency' => $currency_iso_code,
                    'value' => 0
                ],
                'tax-rate' => 0
            ];
        }

        // Set the request body according to the order and customer values
        $body = [];
        $body['payment'] = [
            "merchant-account-resolver-category" => Configuration::get('MERCHANT_ACCOUNT'),
            "request-id" => time() . 'C' . $this->context->cart->id,
            "transaction-type" => "auto-sale",
            "requested-amount" => [
                "value" => $order_value_as_string,
                "currency" => $currency_iso_code
            ],
            "three-d" => [
                "attempt-three-d" => "true",
                "version" => "2.2"
            ],
            "mandate" => [
                "mandate-id" => $this->context->cart->id
            ],
            "order-number" => $this->context->cart->id,
            'locale' => $this->context->language->iso_code,
            "descriptor" => "test",
            "success-redirect-url" => $callback,
            "fail-redirect-url" => $callback,
            "cancel-redirect-url" => $error_callback,
            "ip-address" => "127.0.0.1",
            "account-holder" => [
                "merchant-crm-id" => $customer->id,
                "first-name" => $customer->firstname,
                "last-name" => $customer->lastname,
                "phone" => $address->phone,
                "mobile-phone" => null,
                "work-phone" => null,
                "email" => $customer->email,
                "address" => [
                    "street1" => $address->address1,
                    "street2" => $address->address2,
                    "street3" => null,
                    "city" => $address->city,
                    "postal-code" => $address->postcode,
                    "state" => $state->name,
                    "country" => $country->iso_code,
                ]
            ],
            "shipping" => [
                "shipping-method" => $carrier->name,
                "email" => $customer->email,
                "address" => [
                    "street1" => $address->address1,
                    "street2" => $address->address2,
                    "street3" => null,
                    "city" => $address->city,
                    "postal-code" => $address->postcode,
                    "state" => $state->name,
                    "country" => $country->iso_code,
                ]
            ],
            "order-items" => [
                "order-item" => $products
            ]
        ];

        // If the currency is ZLOTY remove the products from the array
        if ($currency_iso_code == SupportedCurrency::ZLOTY) {
            unset($body['payment']['order-items']);
        }

        // Set the value to creditor id on payment body if its set on the configuration
        $creditor_id = Configuration::get('CREDITOR_ID');
        if ($creditor_id != null && $creditor_id != '') {
            $body['payment']['creditor-id'] = $creditor_id;
        }

        // Set the user as a token to be sent on the Basic Auth
        $token = base64_encode(Configuration::get('ACCOUNT') . ':' . Configuration::get('PASSWORD'));

        // URI to retrieve getnet redirect url
        $uri = $this->payment_url;

        // Make POST request
        try {
            // Creates an new Http client and send the post
            $client = new \GuzzleHttp\Client();
            $response = $client->post($uri, [
                'body' => json_encode($body),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                    'Authorization' => "Basic {$token}"
                ]
            ]);

            $responseContents = $response->getBody()->getContents();

            // Stores the transaction
            $gnrRequest = new GnrRequest();
            $gnrRequest->url = $uri;
            $gnrRequest->req_body = json_encode($body);
            $gnrRequest->req_headers = json_encode([
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'Authorization' => "Basic {$token}"
            ]);
            $gnrRequest->res_code = $response->getStatusCode();
            $gnrRequest->res_headers = json_encode($response->getHeaders());
            $gnrRequest->res_body = $responseContents;
            $gnrRequest->add();

            // Retrieve the response from the request
            $raw_response = (array)json_decode($responseContents);
            $redirect_url = $raw_response['payment-redirect-url'];

            // Retrieve the url and token accodingly to the server reponse
            $url = strstr($redirect_url, '/?', true);
            $token = end(explode('wPaymentToken=', $redirect_url));

            return [
                'url' => $url,
                'token' => $token
            ];
        } catch (\GuzzleHttp\Exception $e) {
            return null;
        }

        return null;
    }
    /* #endregion  paymentOptionsHook */

    /* #region module configuration */
    /**
     * Show the configutaion form on the plugin installation to set the
     * username and the password by creating and HTML String
     *
     * @return string
     */
    public function getContent()
    {
        $output = null;
        $retVal = true;

        if (Tools::isSubmit('submit' . $this->name)) {
            $myModuleAccount = strval(Tools::getValue('ACCOUNT'));
            $myModuleEnvironment = strval(Tools::getValue('ENVIRONMENT'));
            $myModuleMerchantAccount = strval(Tools::getValue('MERCHANT_ACCOUNT'));
            $myModulePass = strval(Tools::getValue('PASSWORD'));
            $myModuleCreditorId = strval(Tools::getValue('CREDITOR_ID'));

            if (!$myModuleEnvironment || empty($myModuleEnvironment) || !Validate::isGenericName(
                    $myModuleEnvironment
                )) {
                $output .= $this->displayError($this->l('Invalid environment value'));
                $retVal = false;
            }
            if (!$myModuleAccount || empty($myModuleAccount) || !Validate::isGenericName($myModuleAccount)) {
                $output .= $this->displayError($this->l('Invalid account value'));
                $retVal = false;
            }
            if (!$myModuleMerchantAccount || empty($myModuleMerchantAccount) || !Validate::isGenericName(
                    $myModuleMerchantAccount
                )) {
                $output .= $this->displayError($this->l('Invalid merchant account value'));
                $retVal = false;
            }
            if (!$myModulePass || empty($myModulePass) || !Validate::isGenericName($myModulePass)) {
                $output .= $this->displayError($this->l('Invalid password value'));
                $retVal = false;
            }
            if (!$myModuleCreditorId || empty($myModuleCreditorId) || !Validate::isGenericName($myModuleCreditorId)) {
                $output .= $this->displayError($this->l('Invalid creditor id value'));
                $retVal = false;
            }
            if ($retVal) {
                Configuration::updateValue('ENVIRONMENT', $myModuleEnvironment);
                Configuration::updateValue('ACCOUNT', $myModuleAccount);
                Configuration::updateValue('PASSWORD', $myModulePass);
                Configuration::updateValue('MERCHANT_ACCOUNT', $myModuleMerchantAccount);
                Configuration::updateValue('CREDITOR_ID', $myModuleCreditorId);
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        return $output . $this->displayForm();
    }

    /**
     * Generate the coinfiguration form to create
     *
     * @return string
     */
    public function displayForm()
    {
        // Get default language
        $defaultLang = (int)Configuration::get('PS_LANG_DEFAULT');

        // Init Fields from array
        $fieldsForm[0]['form'] = [
            'legend' => [
                'title' => $this->l('Configuraciones'),
            ],
            'input' => [
                [
                    'type' => 'switch',
                    'label' => $this->l('Entorno'),
                    'name' => 'ENVIRONMENT',
                    'values' => [
                        ['label' => $this->l('Producción'), 'value' => 'production'],
                        ['label' => $this->l('Desarrollo'), 'value' => 'development'],
                    ],
                    'col' => 3,
                    'required' => true
                ],
                [
                    'type' => 'text',
                    'label' => $this->l('Cuenta del comerciante "resolver category"'),
                    'name' => 'MERCHANT_ACCOUNT',
                    'col' => 3,
                    'required' => true
                ],
                [
                    'type' => 'text',
                    'label' => $this->l('Usuario'),
                    'name' => 'ACCOUNT',
                    'col' => 3,
                    'required' => true
                ],
                [
                    'type' => 'password',
                    'label' => $this->l('Contraseña'),
                    'name' => 'PASSWORD',
                    'col' => 3,
                    'required' => true
                ],
                [
                    'type' => 'text',
                    'label' => $this->l('Id del acredor'),
                    'name' => 'CREDITOR_ID',
                    'col' => 3,
                    'required' => false
                ],
            ],
            'submit' => [
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            ],
        ];

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = $defaultLang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = [
            'save' => [
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
                    '&token=' . Tools::getAdminTokenLite('AdminModules'),
            ],
            'back' => [
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            ]
        ];

        // Load current value
        $helper->fields_value['ENVIRONMENT'] = Tools::getValue('ENVIRONMENT', Configuration::get('ENVIRONMENT'));
        $helper->fields_value['ACCOUNT'] = Tools::getValue('ACCOUNT', Configuration::get('ACCOUNT'));
        $helper->fields_value['MERCHANT_ACCOUNT'] = Tools::getValue(
            'MERCHANT_ACCOUNT',
            Configuration::get('MERCHANT_ACCOUNT')
        );
        $helper->fields_value['PASSWORD'] = Tools::getValue('PASSWORD', Configuration::get('PASSWORD'));
        $helper->fields_value['CREDITOR_ID'] = Tools::getValue('CREDITOR_ID', Configuration::get('CREDITOR_ID'));

        return $helper->generateForm($fieldsForm);
    }

    /* #endregion  configuration */

    public function hookDisplayAdminAfterHeader()
    {
        $this->context->smarty->assign(array(
            'user_orders' => 'MEnu odes'
        ));
    }

    /* #region  paymentReturnHook */
    /**
     * Display a message in the paymentReturn hook
     *
     * @param array $params
     * @return string
     */
    public function hookPaymentReturn($params)
    {
        /**
         * Verify if this module is active
         */
        if (!$this->active) {
            return;
        }

        return $this->fetch('module:getnet/views/templates/hook/payment_return.tpl');
    }

    /* #endregion  paymentReturnHook */

    /* #region  orderStatusUpdateHook */
    /**
     * Manage the order status change.
     *
     * @param array $params
     * @return void
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function hookActionOrderStatusUpdate($params)
    {
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));

        $order_id = $params['id_order'];
        $new_state_id = $params['newOrderStatus']->id;
        // Load order object
        $order = new Order((int)$order_id);
        $current_state = $order->getCurrentOrderState()->id;
        // Load payment object
        $payment_data = OrderPayment::getByOrderReference($order->reference);
        $first_payment = $payment_data[0];
        $payment_method = $first_payment->payment_method;
        $payment_amount = $first_payment->amount;
        $currency = CurrencyCore::getCurrencyInstance($first_payment->id_currency);
        $currency_iso_code = $currency->iso_code;
        $raw_transaction_data = $first_payment->transaction_id;

        $now = new \DateTime();
        // Check if the date is the current day or not to apply cancellation or refund.
        if (
            $now->format('Y-m-d') !== date("Y-m-d", strtotime($first_payment->date_add)) &&
            strtolower($new_state_id) == OrderStatus::ORDER_STATUS_ID_CANCELED
        ) {
            $new_state_id = OrderStatus::ORDER_STATUS_ID_REFUNDED;
        }

        // Check if a getnet cancelation is necessary only from order state "pago aceptado" to "cancelado" state
        if (
            strtolower($payment_method) == 'getnet' &&
            $current_state == OrderStatus::ORDER_STATUS_ID_PAYMENT_ACCEPTED &&
            $new_state_id == OrderStatus::ORDER_STATUS_ID_CANCELED
        ) {
            // Transaction data object
            $transaction_data = (array)json_decode($raw_transaction_data);
            // Cancel the order through the genet api
            $response = $this->getnetUpdateTransactionAction(
                'void',
                $transaction_data,
                $payment_amount,
                $currency_iso_code
            );
            // Add succes message with response
            $this->get('session')->getFlashBag()->add($response['type'], $response['message']);
        }

        // Check if a getnet devolution is necessary only from order state "pago aceptado" to "Reembolsado" state
        if (
            strtolower($payment_method) == 'getnet' &&
            $current_state == OrderStatus::ORDER_STATUS_ID_PAYMENT_ACCEPTED &&
            $new_state_id == OrderStatus::ORDER_STATUS_ID_REFUNDED
        ) {
            // Transaction data object
            $transaction_data = (array)json_decode($raw_transaction_data);
            // Cancel the order through the genet api
            $response = $this->getnetUpdateTransactionAction(
                'refund',
                $transaction_data,
                $payment_amount,
                $currency_iso_code
            );
            // Add succes message with response
            $this->get('session')->getFlashBag()->add($response['type'], $response['message']);
        }
    }

    /**
     * Send the cancelation endpoint to Getnet api.
     *
     * @param string $action
     * @param string $transaction_data
     * @return array|string[] $type , $message
     */
    public function getnetUpdateTransactionAction($action, $transaction_data, $amount, $currency_iso_code)
    {
        // Retrieve individual transaction data
        $transaction_id = $transaction_data['transaction-id'];
        $merchant_account_id = $transaction_data['merchant-account-id'];
        $purchase_transaction_type = $transaction_data['transaction-type'];
        $purchase_payment_method = $transaction_data['payment-method'];

        // Sets the transaction type given the action, purchase payment method and purchase transaction type
        $transaction_type = Transaction::getTransaction($action, $purchase_payment_method, $purchase_transaction_type);

        // If the transaction type is null, return an error
        if (!$transaction_type) {
            $message = $this->l('Operación no soportada');
            $message .= " [{$purchase_payment_method}] [{$purchase_transaction_type}]";
            return [
                'type' => 'error',
                'message' => $message
            ];
        }

        // Set the request body according to the order and customer values
        $body = [];
        $body['payment'] = [
            "merchant-account-id" => [
                "value" => "{$merchant_account_id}"
            ],
            "requested-amount" => [
                "value" => $amount,
                "currency" => $currency_iso_code,
            ],
            "request-id" => time() . 'TId' . $transaction_id,
            "transaction-type" => $transaction_type,
            "ip-address" => "127.0.0.1",
            "parent-transaction-id" => "{$transaction_id}"
        ];

        // Set the user as a token to be sent on the Basic Auth
        $token = base64_encode(Configuration::get('ACCOUNT') . ':' . Configuration::get('PASSWORD'));

        // URI to retrieve getnet redirect url
        $uri = $this->api_url;

        // Response Initialization
        $response = null;

        // Make POST request
        try {
            // Creates an new Http client and send the post
            $client = new \GuzzleHttp\Client();
            $response = $client->post($uri, [
                'body' => json_encode($body),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                    'Authorization' => "Basic {$token}"
                ]
            ]);

            $responseContents = $response->getBody()->getContents();

            // Stores the transaction
            $gnrRequest = new GnrRequest();
            $gnrRequest->url = $uri;
            $gnrRequest->req_body = json_encode($body);
            $gnrRequest->req_headers = json_encode([
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'Authorization' => "Basic {$token}"
            ]);
            $gnrRequest->res_code = $response->getStatusCode();
            $gnrRequest->res_headers = json_encode($response->getHeaders());
            $gnrRequest->res_body = $responseContents;
            $gnrRequest->add();

            // Retrieve the response from the request
            $raw_response = json_decode($responseContents, true);

            // Evaluates the response
            $type = 'success';
            if ($raw_response['payment']['transaction-state'] == 'failed') {
                $description = '';
                foreach ($raw_response['payment']['statuses'] as $status) {
                    foreach ($status as $message) {
                        $description .= $message['description'];
                    }
                }
                $type = 'error';
            }

            return [
                'type' => $type,
                'message' => json_encode($raw_response)
            ];
        } catch (\GuzzleHttp\Exception $e) {
            return [
                'type' => 'error',
                'message' => 'Error en la petición'
            ];
        }
    }
    /* #endregion  orderStatusUpdateHook */

    /**
     * @param $txt
     * @return void
     */
    public static function log($txt)
    {
        $myfile = fopen(_PS_ROOT_DIR_ . '/modules/getnet/log.txt', "a") or die("Unable to open file!");
        fwrite($myfile, date("Y-m-d H:i:s") . " Log: " . $txt . " \n");
        fclose($myfile);
    }
}
