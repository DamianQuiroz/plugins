<?php

require_once _PS_ROOT_DIR_ . '/modules/getnet/library/GnrRequest.php';

class AdminGetNetTransactionsController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
        // Table setup
        $this->bootstrap = true;
        $this->table = 'gnr_request';
        $this->identifier = 'id_request';
        $this->className = 'GnrRequest';
        $this->allow_export = false;
        // List records
        $this->_defaultOrderBy = 'a.id_request';
        $this->_defaultOrderWay = 'DESC';
        $this->_select = 'a.id_request, a.url, a.req_headers, a.req_body, a.res_code, a.res_headers, a.res_body';
        $this->fields_list = [
            'id_request' => ['title' => 'ID', 'class' => 'fixed-width-xs', 'remove_onclick' => true],
            'url' => ['title' => 'URL', 'remove_onclick' => true],
            'req_headers' => ['title' => 'Req. Headers', 'remove_onclick' => true],
            'req_body' => ['title' => 'Req. Body', 'remove_onclick' => true],
            'res_code' => ['title' => 'Res. Code', 'remove_onclick' => true],
            'res_headers' => ['title' => 'Res. Headers', 'remove_onclick' => true],
            'res_body' => ['title' => 'Res. Body', 'remove_onclick' => true],
        ];
    }
}
